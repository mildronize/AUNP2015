#ifndef	_PDASH_H_
#define	_PDASH_H_

void    pdash(int);

#endif

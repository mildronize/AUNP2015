#include <stdio.h>

void	pdot(int n) {
	int	i;

	for (i=0;i<n;i++) printf(".");
}

#ifndef	_REV_H_
#define	_REV_H_

#define	REVBUFSZ	20
char	*rev(char *);

#endif

#ifndef	_PDOT_H_
#define	_PDOT_H_

void    pdot(int);

#endif

#include <stdio.h>

void	pdash(int n) {
	int	i;

	for (i=0;i<n;i++) printf("-");
}

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "rev.h"

int	main(void) {
	char	*s="Hello World";

	printf("%s\n", rev(s));
	printf("%s\n", rev("This is a test"));
	exit(0);
}
